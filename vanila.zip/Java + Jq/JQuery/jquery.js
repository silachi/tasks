$(document).ready(function(){
    $("p").css("background-color","yellow");
    console.log("hello");
});